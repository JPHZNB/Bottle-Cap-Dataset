%% --------------- 参数设置（根据需求修改这里）---------------
video_path = 'D:\瓶盖项目\文件\shujuji\shipin\6.mp4';       % 视频路径（支持mp4/avi等格式）
output_dir = 'D:\瓶盖项目\文件\shujuji\6';   % 输出图片文件夹（自动创建）
%% --------------- 核心参数配置 ---------------
total_original = 20;               % 原始无处理帧数量（前20张）
% 噪声与模糊参数（后20张使用）
salt_pepper_density = 0.01;         % 椒盐噪声密度20%
gaussian_sigma = 1;               % 高斯噪声σ=10（方差=σ²=100）
motion_kernel_size = 1;           % 运动模糊核15×15
motion_angle = 45;                 % 运动模糊方向（45度，可调整）

%% --------------- 初始化 ---------------
% 创建输出文件夹
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

% 读取视频信息
video = VideoReader(video_path);
total_video_frames = video.NumFrames;

% 检查视频帧数是否足够（至少需要20帧作为原始帧）
if total_video_frames < total_original
    error('视频帧数不足！至少需要%d帧，当前视频仅%d帧', total_original, total_video_frames);
end

%% --------------- 提取前20张无处理帧（1-20）---------------
fprintf('开始提取前20张无处理帧...\n');
original_frames = cell(1, total_original);  % 存储原始帧，用于后续处理

for i = 1:total_original
    % 均匀从视频中取20帧（避免集中在开头）
    frame_idx = round(i * total_video_frames / (total_original + 1));
    frame = read(video, frame_idx);  % 读取帧
    frame = im2uint8(frame);         % 转为uint8格式（0-255）
    original_frames{i} = frame;      % 保存原始帧供后续处理
    
    % 保存为第i张（1-20）
    save_name = fullfile(output_dir, sprintf('%d.jpg', i));
    imwrite(frame, save_name);
    fprintf('已保存无处理帧：%s\n', save_name);
end

%% --------------- 处理后20张（21-40，基于前20张原始帧）---------------
fprintf('\n开始处理后20张帧（含噪声和模糊）...\n');
% 生成运动模糊核（15×15）
motion_kernel = fspecial('motion', motion_kernel_size, motion_angle);

for i = 1:total_original
    % 取出对应的原始帧
    frame = original_frames{i};
    
    % 1. 添加椒盐噪声（密度20%）
    frame_noise = imnoise(frame, 'salt & pepper', salt_pepper_density);
    
    % 2. 添加高斯噪声（σ=10，方差=100）
    % 注意：imnoise的高斯噪声参数为均值和方差，这里均值0，方差=σ²=100
    frame_noise = imnoise(frame_noise, 'gaussian', 0, (gaussian_sigma/255)^2);
    % （除以255是因为imnoise对uint8图像的方差参数需归一化到0-1范围）
    
    % 3. 添加运动模糊（15×15核）
    frame_processed = imfilter(frame_noise, motion_kernel, 'replicate');  % 边缘填充避免黑边
    
    % 保存为第20+i张（21-40）
    save_name = fullfile(output_dir, sprintf('%d.jpg', total_original + i));
    imwrite(frame_processed, save_name);
    fprintf('已保存处理帧：%s\n', save_name);
end

fprintf('\n全部完成！共生成40张图片，保存至文件夹：%s\n', output_dir);